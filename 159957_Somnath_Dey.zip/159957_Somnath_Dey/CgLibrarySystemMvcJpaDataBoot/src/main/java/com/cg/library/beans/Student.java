package com.cg.library.beans;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotEmpty;
@SequenceGenerator(name="sequenceGenerator",initialValue=1001,allocationSize=1)
@Entity
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="sequenceGenerator")
	private int studentID;
	@NotEmpty
	private String firstName;
	@NotEmpty
	private String lastName;
	@NotEmpty
	private String emailID;
	@NotEmpty
	private String mobileNo;
	private String registerDate;
	@Embedded
	private Address address;
	@OneToMany(mappedBy="student",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Book> books;
	public Student() {}
	public Student(int studentID, String firstName, String lastName, String emailID, String mobileNo, String registerDate,
			Address address, List<Book> books) {
		super();
		this.studentID = studentID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.mobileNo = mobileNo;
		this.registerDate = registerDate;
		this.address = address;
		this.books = books;
	}
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getregisterDate() {
		return registerDate;
	}
	public void setregisterDate(String registerDate) {
		this.registerDate = registerDate;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", firstName=" + firstName + ", lastName=" + lastName + ", emailID="
				+ emailID + ", mobileNo=" + mobileNo + ", registerDate=" + registerDate + ", address=" + address + ", books=" + books
				+ "]";
	}

}
