package com.cg.library.controllers;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.exception.BookAlreadyPresentException;
import com.cg.library.exception.BookNotFoundException;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.exception.RegistrationDateNotFound;
import com.cg.library.exception.StudentNotFoundException;
import com.cg.library.services.LibraryServices;
@Controller
public class StudentController {
	@Autowired
	LibraryServices libraryServices;
	Book book;
	Student student;
	@RequestMapping("/registrationSuccessful")
	public ModelAndView getRegistration(@Valid@ModelAttribute Student student,BindingResult bindingresult) throws LibraryServicesDownException {
		if(bindingresult.hasErrors())
			return new ModelAndView("registerPage");
		student=libraryServices.registerStudent(student);
		return new ModelAndView("registrationSuccessPage","student",student);
	}
	@RequestMapping("/getLoginPage")
	public ModelAndView getLoginPage(@RequestParam("studentID")int studentID,@RequestParam("registerDate")String registerDate) throws LibraryServicesDownException {
		try {
			libraryServices.loginStudent(studentID,registerDate);	
		} catch (StudentNotFoundException e) {
			return new ModelAndView("loginPage","errorMesssage","Student ID not found!!Please try again");
		} catch (RegistrationDateNotFound e) {
			return new ModelAndView("loginPage","errorMesssage","Registration Date dont match!Please try again");

		}
		return new ModelAndView("libraryIndexPage");
	}

	@RequestMapping("/viewAllBook")
	public ModelAndView getAllBooks(){
		List<Book> bookList=libraryServices.viewAllBook();
		return new ModelAndView("viewAllBookPage","bookList",bookList);
	}
	@RequestMapping("/viewAllAdminBook")
	public ModelAndView getAllAdminBooks(){
		List<Book> bookList=libraryServices.viewAllBook();
		return new ModelAndView("viewAllAdminBookPage","bookList",bookList);
	}
	@RequestMapping("/getBookIssue")
	public ModelAndView getBookIssue(@RequestParam("bookID")int bookID) throws BookNotFoundException {
		try {
			Book book=libraryServices.issueBook(bookID);
			return new ModelAndView("bookIssueSuccessful","book",book);
		} catch (BookNotFoundException e) {
			return new ModelAndView("getBookIssuePage","errorMesssage","Book ID not found!!Please try again");
		}
	}

	@RequestMapping("/getBookReturn")
	public ModelAndView getBookReturn(@RequestParam("bookID")int bookID) throws BookNotFoundException,BookAlreadyPresentException {
		try {
			long fine=libraryServices.returnBook(bookID);
			return new ModelAndView("bookReturnSuccessful","fine",fine);
		} catch (BookAlreadyPresentException e) {
			return new ModelAndView("getBookReturnPage","errorMesssage","Please enter correct bookID!!");
		}/*catch (BookNotFoundException e) {
			return new ModelAndView("getBookReturnPage","errorMesssage","No match in database,Please enter correct bookID!!");
				}*/
	}

	@RequestMapping("/getAddBook")
	public ModelAndView getAddBook(@RequestParam("bookName")String bookName,@RequestParam("bookAuthor")String bookAuthor){
		List<Book> books=libraryServices.addBook(bookName, bookAuthor);
		return new ModelAndView("addedBookPage","books",books);
	}

	@RequestMapping("/getRemoveBook")
	public ModelAndView getRemoveBook(@RequestParam("bookID")int bookID){
		try {
			libraryServices.removeBook(bookID);
			return new ModelAndView("getAdminPage","successMessage","Your Book is successfully removed");

		} catch (BookNotFoundException e) {
			return new ModelAndView("getRemoveBookPage","errorMesssage","Please enter correct bookID!!");
		}
	}
	
	@RequestMapping("/getUpdateBook")
	public ModelAndView getUpdateBook(@RequestParam("bookID")int bookID,@RequestParam("bookName")String bookName){
		try {
			libraryServices.updateBook(bookID, bookName);
		} catch (BookNotFoundException e) {
			return new ModelAndView("getUpdateBookPage","errorMesssage","Please enter correct bookID!!");
			
		}
		return new ModelAndView("getAdminPage","successMessage","Your Book is successfully updated");

	}
	
}
