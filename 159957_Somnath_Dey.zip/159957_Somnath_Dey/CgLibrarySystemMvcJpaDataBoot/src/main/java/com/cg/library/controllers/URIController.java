package com.cg.library.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.library.beans.Student;

@Controller
public class URIController {
	Student student;
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("register")
	public String getRegisterPage() {
		return "registerPage";
	}
	@RequestMapping("login")
	public String getLoginPage() {
		return "loginPage";
	}
	@ModelAttribute
	public Student getStudent() {
		student= new Student();
		return student;
	}
	
	@RequestMapping("libraryPage")
	public String getLibraryPage() {
		return "libraryIndexPage";
	}
	
	@RequestMapping("issueBook")
	public String getIssueBook() {
		return "getBookIssuePage";
	}
	
	@RequestMapping("returnBook")
	public String getReturnBook() {
		return "getBookReturnPage";
	}
	
	@RequestMapping("admin")
	public String getAdminPage() {
		return "getAdminPage";
	}
	
	@RequestMapping("addBook")
	public String getAddBook() {
		return "getAddBookPage";
	}
	
	@RequestMapping("removeBook")
	public String getRemoveBook() {
		return "getRemoveBookPage";
	}
	
	@RequestMapping("updateBook")
	public String getUpdateBook() {
		return "getUpdateBookPage";
	}
}
