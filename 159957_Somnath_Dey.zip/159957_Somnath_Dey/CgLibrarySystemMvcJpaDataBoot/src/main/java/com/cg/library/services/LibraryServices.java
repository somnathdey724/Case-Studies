package com.cg.library.services;

import java.util.Date;
import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.exception.BookAlreadyPresentException;
import com.cg.library.exception.BookNotFoundException;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.exception.RegistrationDateNotFound;
import com.cg.library.exception.StudentNotFoundException;

public interface LibraryServices {
	public Student registerStudent(Student student) throws LibraryServicesDownException;
	public void loginStudent(int studentID,String registerDate)throws LibraryServicesDownException, StudentNotFoundException, RegistrationDateNotFound;
	public Book issueBook(int bookID) throws BookNotFoundException;
	public List<Book> addBook(String bookName,String bookAuthor);
	public void removeBook(int bookID) throws BookNotFoundException;
	public void updateBook(int bookID,String bookName)throws BookNotFoundException;
	public long returnBook(int bookID) throws BookAlreadyPresentException, BookNotFoundException;
	public int calculateFine(int studentID,int bookID) throws StudentNotFoundException,BookNotFoundException;
	public List<Book> viewAllBook();
	public Book viewStudentBookDetails(Student studentID)throws StudentNotFoundException;
}
